Description of file: *.rvs.dat
--------------------------------------------------------------------------------
Col Units  Explanations
-------------------------------------------------------------------------
1   BJD    Barycentric Julian date of observation
2   m/s    Radial velocity
3   m/s    Radial velocity uncertainty
4   --     Instrument

Description of file: *.lc.dat
--------------------------------------------------------------------------------
Col Units  Explanations
-------------------------------------------------------------------------
1   BJD    Barycentric Julian date of observation
2   --     Photometric relative flux
3   --     Photometric uncertainty
4   --     Instrument
